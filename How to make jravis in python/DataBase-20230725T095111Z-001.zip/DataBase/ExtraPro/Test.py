from time import sleep
import pyautogui

sleep(4)

kk = pyautogui.position()

print(kk)
